"""Build the all-policies context tables (NOT split organic vs conventional):
cause-of-loss summary and policy counts. Reads pickles from col_worker.py and
pol_worker.py. Run from the repo root.

NOTE: these tables cannot be split organic vs conventional — only the SOBTPU
file carries the organic practice flag, and it has no cause-of-loss or policy
counts; the cause-of-loss and state/county/crop files have no practice field.
"""
import pickle, glob, os
import pandas as pd, numpy as np

ROOT = os.environ.get("REPO_ROOT", os.getcwd())
OUT  = os.path.join(ROOT, "crop_loss_data", "organic_analysis")
WORK = os.path.join(OUT, "_work")
os.makedirs(OUT, exist_ok=True)

# ---- cause of loss ----
cause, cyear = {}, {}
for f in sorted(glob.glob(os.path.join(WORK, "col_part*.pkl"))):
    d = pickle.load(open(f,'rb'))
    for k,v in d['cause'].items():
        a=cause.setdefault(k,[0.,0.,0.,0.])
        for i in range(4): a[i]+=v[i]
    for k,v in d['cause_year'].items():
        cyear[k]=cyear.get(k,0.)+v
if cause:
    tot=sum(v[0] for v in cause.values())
    cdf=pd.DataFrame([{"cause_of_loss":k,"indemnity":v[0],
        "pct_of_indemnity":(v[0]/tot if tot else np.nan),
        "policies_indemnified":int(v[1]),"premium":v[2],
        "loss_ratio":(v[0]/v[2] if v[2]>0 else np.nan)} for k,v in cause.items()]
        ).sort_values("indemnity",ascending=False)
    cdf.to_csv(f"{OUT}/cause_of_loss_summary.csv",index=False)
    top8=cdf.head(8)["cause_of_loss"].tolist()
    yrs=sorted({y for (c,y) in cyear})
    tr=[]
    for y in yrs:
        ytot=sum(cyear.get((c,y),0.) for c in cause)
        tr.append({"year":y, **{c:(cyear.get((c,y),0.)/ytot if ytot else np.nan) for c in top8}})
    pd.DataFrame(tr).to_csv(f"{OUT}/cause_of_loss_by_year_share.csv",index=False)
    print(f"cause-of-loss tables written ({len(cdf)} perils, ${tot:,.0f} total).")

# ---- policy counts ----
yd, cd, pl = {}, {}, {}
for f in sorted(glob.glob(os.path.join(WORK, "pol_part*.pkl"))):
    d = pickle.load(open(f,'rb'))
    for src,dst in [(d['year'],yd),(d['crop'],cd),(d['plan'],pl)]:
        for k,v in src.items():
            a=dst.setdefault(k,[0.,0.,0.])
            for i in range(3): a[i]+=v[i]
def pc(d,key):
    return pd.DataFrame([{key:k,"policies_sold":int(v[0]),
        "policies_earning_premium":int(v[1]),"policies_indemnified":int(v[2])} for k,v in d.items()])
if yd:
    pc(yd,"year").sort_values("year").to_csv(f"{OUT}/policy_counts_year.csv",index=False)
    pc(cd,"crop").sort_values("policies_earning_premium",ascending=False).to_csv(f"{OUT}/policy_counts_crop.csv",index=False)
    pc(pl,"plan").sort_values("policies_earning_premium",ascending=False).to_csv(f"{OUT}/policy_counts_plan.csv",index=False)
    print("policy-count tables written.")
