import sys, glob, os, pickle
import pandas as pd

DATA_DIR=sys.argv[1]; START,END=int(sys.argv[2]),int(sys.argv[3]); OUT=sys.argv[4]
files=sorted(glob.glob(os.path.join(DATA_DIR,"sobcov*.txt"))+glob.glob(os.path.join(DATA_DIR,"SOBSCC*.txt")))[START:END]

# state_county_crop layout (0-based): 0 year, 6 commodity, 8 plan,
# 12 policies sold, 13 policies earning, 14 policies indemnified, 21 premium, 26 indemnity
cols=[0,6,8,12,13,14,21,26]; names=['year','crop','plan','sold','earn','ind','prem','indem']

yeard={}   # year -> [sold,earn,ind]  (all years)
cropd={}   # crop -> [sold,earn,ind]  (2011-2023)
pland={}   # plan -> [sold,earn,ind]  (2011-2023)
for fp in files:
    print("pol", os.path.basename(fp), flush=True)
    df=pd.read_csv(fp,sep='|',header=None,usecols=cols,names=names,dtype=str,encoding='latin-1',engine='c')
    for c in ['sold','earn','ind']:
        df[c]=pd.to_numeric(df[c],errors='coerce').fillna(0.0)
    df['year']=pd.to_numeric(df['year'],errors='coerce')
    gy=df.groupby('year').agg(sold=('sold','sum'),earn=('earn','sum'),ind=('ind','sum')).reset_index()
    for r in gy.itertuples(index=False):
        if pd.isna(r.year): continue
        a=yeard.setdefault(int(r.year),[0.,0.,0.]); a[0]+=r.sold;a[1]+=r.earn;a[2]+=r.ind
    dm=df[(df.year>=2011)&(df.year<=2023)]
    gc=dm.groupby('crop').agg(sold=('sold','sum'),earn=('earn','sum'),ind=('ind','sum')).reset_index()
    for r in gc.itertuples(index=False):
        a=cropd.setdefault(r.crop.strip(),[0.,0.,0.]); a[0]+=r.sold;a[1]+=r.earn;a[2]+=r.ind
    gp=dm.groupby('plan').agg(sold=('sold','sum'),earn=('earn','sum'),ind=('ind','sum')).reset_index()
    for r in gp.itertuples(index=False):
        a=pland.setdefault(r.plan.strip(),[0.,0.,0.]); a[0]+=r.sold;a[1]+=r.earn;a[2]+=r.ind
pickle.dump({'year':yeard,'crop':cropd,'plan':pland},open(OUT,'wb'))
print("done",OUT,flush=True)
