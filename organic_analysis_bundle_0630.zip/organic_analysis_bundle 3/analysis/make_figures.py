"""Generate the 4 figures from the summary CSVs (run combine_main.py first).
Run from the repo root. Outputs -> crop_loss_data/organic_analysis/figures/."""
import os
import pandas as pd, numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.environ.get("REPO_ROOT", os.getcwd())
BASE = os.path.join(ROOT, "crop_loss_data", "organic_analysis")
FIG  = os.path.join(BASE, "figures")
os.makedirs(FIG, exist_ok=True)
ORG, CONV = "#2e8b57", "#7f7f7f"

yr = pd.read_csv(f"{BASE}/by_year_summary.csv").sort_values("year")
cr = pd.read_csv(f"{BASE}/by_crop_summary.csv")
pr = pd.read_csv(f"{BASE}/county_comparison_paired.csv")

# fig1: by year (loss ratio + loss cost)
fig, ax = plt.subplots(1, 2, figsize=(13,5))
for a, m, t in [(ax[0],"loss_ratio","Loss ratio (indemnity / premium)"),
                (ax[1],"loss_cost","Loss cost (indemnity / liability)")]:
    a.plot(yr["year"], yr[f"{m}_organic"], "-o", color=ORG, label="Organic", ms=4)
    a.plot(yr["year"], yr[f"{m}_conventional"], "-o", color=CONV, label="Conventional", ms=4)
    a.axvspan(2023.5, 2025.5, color="red", alpha=0.07)
    a.text(2024.5, a.get_ylim()[1]*0.92, "immature\n(2024-25)", ha="center", fontsize=8, color="firebrick")
    if m=="loss_ratio":
        a.axhline(1.0, ls="--", lw=1, color="black", alpha=.5); a.text(yr["year"].min(), 1.03, "break-even = 1.0", fontsize=8)
    a.set_title(t); a.set_xlabel("Crop year"); a.legend(); a.grid(alpha=.3)
fig.suptitle("Organic vs Conventional crop-insurance experience by year (RMA SOBTPU)", fontsize=12)
fig.tight_layout(); fig.savefig(f"{FIG}/fig1_by_year.png", dpi=150); plt.close(fig)

# fig2: paired scatter
fig, ax = plt.subplots(figsize=(7.5,7))
x = pr["loss_ratio_conventional"].clip(0,5); y = pr["loss_ratio_organic"].clip(0,5)
s = (pr["premium_organic"]/pr["premium_organic"].max()*400)+8
ax.scatter(x, y, s=s, color=ORG, alpha=.45, edgecolor="white", linewidth=.4)
ax.plot([0,5],[0,5],"--",color="black",lw=1); ax.text(3.4,3.1,"45° line\n(equal risk)",fontsize=9)
ax.set_xlim(0,5); ax.set_ylim(0,5); ax.set_xlabel("Conventional loss ratio"); ax.set_ylabel("Organic loss ratio")
above = (pr["lr_diff"]>0).mean()*100
ax.set_title(f"County-level paired comparison ({len(pr)} counties)\nOrganic riskier (above line) in {above:.0f}% — bubble = organic premium")
ax.grid(alpha=.3); fig.tight_layout(); fig.savefig(f"{FIG}/fig2_paired_scatter.png", dpi=150); plt.close(fig)

# fig3: by crop
ct = cr.set_index("crop")
top = ct.sort_values("premium_organic", ascending=False).head(12).iloc[::-1]
fig, ax = plt.subplots(figsize=(10,7)); yidx=np.arange(len(top)); h=.4
ax.barh(yidx+h/2, top["loss_ratio_organic"], h, color=ORG, label="Organic")
ax.barh(yidx-h/2, top["loss_ratio_conventional"], h, color=CONV, label="Conventional")
ax.axvline(1.0, ls="--", color="black", lw=1, alpha=.6)
ax.set_yticks(yidx); ax.set_yticklabels(top.index); ax.set_xlabel("Loss ratio (indemnity / premium)")
ax.set_title("Loss ratio by crop (top 12 by organic premium)"); ax.legend(); ax.grid(axis="x", alpha=.3)
fig.tight_layout(); fig.savefig(f"{FIG}/fig3_by_crop.png", dpi=150); plt.close(fig)

# fig4: distribution
fig, ax = plt.subplots(figsize=(7,6))
data=[pr["loss_ratio_conventional"].clip(0,5), pr["loss_ratio_organic"].clip(0,5)]
bp=ax.boxplot(data, tick_labels=["Conventional","Organic"], patch_artist=True, showmeans=True, widths=.5)
for patch,c in zip(bp["boxes"],[CONV,ORG]): patch.set_facecolor(c); patch.set_alpha(.6)
ax.axhline(1.0, ls="--", color="black", lw=1, alpha=.6); ax.set_ylabel("County loss ratio (clipped at 5)")
ax.set_title(f"Distribution of county loss ratios ({len(pr)} paired counties)"); ax.grid(axis="y", alpha=.3)
fig.tight_layout(); fig.savefig(f"{FIG}/fig4_distribution.png", dpi=150); plt.close(fig)
print(f"figures written to {FIG}/")
