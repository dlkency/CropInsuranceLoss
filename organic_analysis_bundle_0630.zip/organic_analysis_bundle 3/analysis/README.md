# Organic vs. Conventional Loss Analysis — `analysis/`

Reproduces the organic-vs-conventional crop-insurance loss analysis from the
raw RMA Summary of Business data.

## Requirements
```
pip install pandas numpy matplotlib openpyxl scipy
```

## How to run
From the **repo root**:
```
python read_crop_loss_api.py     # 1. download raw RMA data into crop_loss_data/ (large, ~3-4 GB)
bash analysis/run_all.sh         # 2. run the whole analysis
```
Outputs land in `crop_loss_data/organic_analysis/` (CSV tables + `figures/`) and
`organic_vs_conventional_data.xlsx` at the repo root.

## What each script does
| Script | Role |
|---|---|
| `agg_worker.py` | Streams the SOBTPU files, classifies each record organic vs conventional from the Practice Name, aggregates premium / indemnity / liability / subsidy by county, crop, year, and insurance plan. |
| `combine_main.py` | Turns that aggregate into the headline tables: national, by year, by crop, by insurance plan, and the county / paired-county comparisons. |
| `make_figures.py` | The four figures (by-year, paired scatter, by-crop, distribution). |
| `col_worker.py` + `combine_extras.py` | Cause-of-loss summary (all policies). |
| `pol_worker.py` + `combine_extras.py` | Policy-count tables (all policies). |
| `build_workbook.py` | Assembles every table into the multi-tab Excel workbook. |
| `run_all.sh` | Runs all of the above in order. |

The `*_worker.py` scripts take `DATA_DIR START END OUT_PICKLE` arguments and write
a small intermediate pickle to `crop_loss_data/organic_analysis/_work/` (gitignored).
`START`/`END` slice the file list; `0 9999` processes everything in one pass.

## Method notes
- **Organic flag:** a record is organic if its Practice Name contains "organic"
  (covers Certified / Transitional × Irrigated / Non-Irrigated). Only the SOBTPU
  file carries this flag.
- **Two metrics:** loss ratio = indemnity / premium (rating adequacy); loss cost =
  indemnity / liability (objective risk, pricing-independent). All ratios are
  premium-/liability-weighted, not means of per-record ratios.
- **Windows:** county/crop/plan cross-sections use mature years **2011–2023**
  (organic is negligible before 2011; 2024–25 indemnities are not yet settled).
  The by-year series keeps the full range and flags 2024–25 as immature.
- **Paired counties:** counties with both practices and ≥ $10k organic premium.

## Data limitation (important)
`cause_of_loss_*` and `policy_counts_*` tables are **all-policies, NOT split
organic vs conventional** — only SOBTPU carries the organic flag, and it has no
cause-of-loss or policy-count fields; the files that do have no practice field.
Policy counts are summed at the line-item level, so multi-county/crop policies are
counted more than once (treat as approximate totals / trends).
