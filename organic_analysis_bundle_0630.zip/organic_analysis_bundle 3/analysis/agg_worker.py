import sys, glob, os, pickle
import pandas as pd, numpy as np

DATA_DIR = sys.argv[1]
START, END = int(sys.argv[2]), int(sys.argv[3])
OUT = sys.argv[4]

files = sorted(set(glob.glob(os.path.join(DATA_DIR, "SOBSCCTPU*.TXT")) +
                   glob.glob(os.path.join(DATA_DIR, "SOBSCCTPU*.txt"))))[START:END]

# pandas read_csv sorts usecols ascending -> names must be in ascending-position order.
# 0=year 1=state code 3=state abbr 4=county code 7=commodity 9=insurance plan abbr
# 16=practice 21=liability 22=premium 23=subsidy 24=indemnity
cols  = [0, 1, 3, 4, 7, 9, 16, 21, 22, 23, 24]
names = ['year','sc','abbr','cc','crop','plan','prac','liab','prem','subsidy','indem']

# value vectors: [prem, indem, liab, subsidy, recs]
county = {}   # (fips,state,practice)
crop   = {}   # (crop,practice)
year   = {}   # (year,practice)
plan   = {}   # (plan,practice)
nat = {'organic':[0.,0.,0.,0.,0], 'conventional':[0.,0.,0.,0.,0]}
org_names = set()

def accum(d, key, r):
    a = d.setdefault(key, [0.,0.,0.,0.,0])
    a[0]+=r.prem; a[1]+=r.indem; a[2]+=r.liab; a[3]+=r.subsidy; a[4]+=r.recs

for fp in files:
    print("worker reading", os.path.basename(fp), flush=True)
    df = pd.read_csv(fp, sep='|', header=None, usecols=cols, names=names,
                     dtype=str, encoding='latin-1', engine='c')
    for c in ['prem','indem','liab','subsidy']:
        df[c] = pd.to_numeric(df[c], errors='coerce').fillna(0.0)
    df = df[df['prem'] > 0]
    df['organic'] = df['prac'].str.lower().str.contains('organic', na=False)
    org_names.update(df.loc[df['organic'], 'prac'].unique().tolist())
    df['practice'] = np.where(df['organic'], 'organic', 'conventional')
    df['fips']  = df['sc'].str.strip().str.zfill(2) + df['cc'].str.strip().str.zfill(3)
    df['state'] = df['abbr'].str.strip()
    df['plan']  = df['plan'].str.strip()

    AGG = dict(prem=('prem','sum'), indem=('indem','sum'), liab=('liab','sum'),
               subsidy=('subsidy','sum'), recs=('prem','size'))

    # year + plan keep ALL years; county + crop use mature window 2011-2023
    gy = df.groupby(['year','practice']).agg(**AGG).reset_index()
    for r in gy.itertuples(index=False): accum(year, (r.year, r.practice), r)

    yr_int = pd.to_numeric(df['year'], errors='coerce')
    dfm = df[(yr_int >= 2011) & (yr_int <= 2023)]

    gp = dfm.groupby(['plan','practice']).agg(**AGG).reset_index()
    for r in gp.itertuples(index=False): accum(plan, (r.plan, r.practice), r)

    g = dfm.groupby(['fips','state','practice']).agg(**AGG).reset_index()
    for r in g.itertuples(index=False): accum(county, (r.fips, r.state, r.practice), r)

    gc = dfm.groupby(['crop','practice']).agg(**AGG).reset_index()
    for r in gc.itertuples(index=False): accum(crop, (r.crop, r.practice), r)

    gn = df.groupby('practice').agg(**AGG).reset_index()
    for r in gn.itertuples(index=False):
        a = nat[r.practice]; a[0]+=r.prem; a[1]+=r.indem; a[2]+=r.liab; a[3]+=r.subsidy; a[4]+=r.recs

pickle.dump({'county':county,'crop':crop,'year':year,'plan':plan,'nat':nat,'org_names':org_names},
            open(OUT,'wb'))
print("worker done ->", OUT, flush=True)
