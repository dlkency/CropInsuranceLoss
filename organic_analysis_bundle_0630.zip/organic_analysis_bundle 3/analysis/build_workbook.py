import os
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

ROOT = os.environ.get("REPO_ROOT", os.getcwd())
BASE = os.path.join(ROOT, "crop_loss_data", "organic_analysis")
OUT  = os.path.join(ROOT, "organic_vs_conventional_data.xlsx")

HEAD_FILL = PatternFill("solid", fgColor="1F4E37")   # dark green
HEAD_FONT = Font(bold=True, color="FFFFFF", name="Arial", size=11)
BASE_FONT = Font(name="Arial", size=10)
IMMATURE_FILL = PatternFill("solid", fgColor="FCE4E4")  # light red
thin = Side(style="thin", color="DDDDDD")
BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)

CUR = '$#,##0;($#,##0);"-"'
RATIO = '0.00'
COST = '0.000'
INT = '#,##0'

def style_header(ws, ncol):
    for c in range(1, ncol+1):
        cell = ws.cell(row=1, column=c)
        cell.fill = HEAD_FILL; cell.font = HEAD_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = BORDER
    ws.freeze_panes = "A2"
    ws.row_dimensions[1].height = 30

def write_df(ws, df, fmts, widths):
    ws.append(list(df.columns))
    for _, r in df.iterrows():
        ws.append(list(r.values))
    style_header(ws, len(df.columns))
    for ci, col in enumerate(df.columns, start=1):
        L = get_column_letter(ci)
        ws.column_dimensions[L].width = widths.get(col, 14)
        f = fmts.get(col)
        for ri in range(2, ws.max_row+1):
            cell = ws.cell(row=ri, column=ci)
            cell.font = BASE_FONT
            if f: cell.number_format = f

wb = Workbook()

# ---------- Notes sheet ----------
ws = wb.active; ws.title = "Notes"
notes = [
 ("Organic vs. Conventional Crop-Insurance Loss — Data Workbook", 14, True),
 ("", 10, False),
 ("Source: USDA RMA Summary of Business – Type/Practice/Unit (SOBTPU), 2002–2025,", 10, False),
 ("downloaded via the updated read_crop_loss_api.py.", 10, False),
 ("", 10, False),
 ("Metric definitions:", 11, True),
 ("  Loss ratio = Indemnity ÷ Premium  (rating adequacy; >1.0 = unprofitable)", 10, False),
 ("  Loss cost  = Indemnity ÷ Liability (objective risk per $ insured)", 10, False),
 ("  All ratios are premium-weighted (Σindemnity ÷ Σpremium), not averages of per-record ratios.", 10, False),
 ("", 10, False),
 ("Data-quality handling:", 11, True),
 ("  • 2024–2025 are IMMATURE (claims not fully settled) — excluded from county/crop stats,", 10, False),
 ("    shown but flagged in the By Year tab. Do not draw conclusions from them.", 10, False),
 ("  • Pre-2011 organic is sparse — county/crop tabs use the 2011–2023 window.", 10, False),
 ("  • Paired-county tab requires ≥ $10,000 organic premium per county.", 10, False),
 ("", 10, False),
 ("  Subsidy = subsidized premium amount; Subsidy rate = Subsidy / Total Premium.", 10, False),
 ("", 10, False),
 ("Tabs:", 11, True),
 ("  National          — pooled organic vs conventional, all years", 10, False),
 ("  By Year           — annual loss ratio & loss cost (2024–25 highlighted as immature)", 10, False),
 ("  By Insurance Plan — loss ratio/cost/subsidy by RMA plan (RP, APH, YP, ...), 2011–2023", 10, False),
 ("  By Crop           — by commodity, 2011–2023, sorted by organic premium", 10, False),
 ("  County (all)      — every county with the practice, 2011–2023", 10, False),
 ("  County paired     — counties with BOTH practices (the cleanest comparison)", 10, False),
 ("", 10, False),
 ("Data limitation:", 11, True),
 ("  'Policies Earning Premium', 'Policies Indemnified' and 'Cause of Loss' canNOT be split", 10, False),
 ("  organic vs conventional: only the SOBTPU file carries the organic practice flag, and it", 10, False),
 ("  has no policy counts; the policy-count and cause-of-loss files have no practice field.", 10, False),
]
for i,(txt,sz,bold) in enumerate(notes, start=1):
    c = ws.cell(row=i, column=1, value=txt)
    c.font = Font(name="Arial", size=sz, bold=bold, color=("1F4E37" if bold and sz>=13 else "000000"))
ws.column_dimensions["A"].width = 95

# ---------- helpers to reshape ----------
def reorder(df):
    front = [c for c in ["fips","state","year","plan","crop","cause_of_loss","practice","records"] if c in df.columns]
    pairs = []
    for stem in ["loss_ratio","loss_cost","premium","subsidy","subsidy_rate","indemnity","liability"]:
        for suf in ["organic","conventional"]:
            col = f"{stem}_{suf}"
            if col in df.columns: pairs.append(col)
    rest = [c for c in df.columns if c not in front+pairs]
    return df[front+pairs+rest]

PCT = '0.0%'
RENAME = {
 "fips":"FIPS","state":"State","year":"Year","crop":"Crop","practice":"Practice","records":"Records","plan":"Insurance Plan",
 "loss_ratio":"Loss ratio","loss_cost":"Loss cost","premium":"Premium ($)","indemnity":"Indemnity ($)","liability":"Liability ($)",
 "subsidy":"Subsidy ($)","subsidy_rate":"Subsidy rate %",
 "loss_ratio_organic":"Loss ratio (Org)","loss_ratio_conventional":"Loss ratio (Conv)",
 "loss_cost_organic":"Loss cost (Org)","loss_cost_conventional":"Loss cost (Conv)",
 "premium_organic":"Premium Org ($)","premium_conventional":"Premium Conv ($)",
 "subsidy_organic":"Subsidy Org ($)","subsidy_conventional":"Subsidy Conv ($)",
 "subsidy_rate_organic":"Subsidy% Org","subsidy_rate_conventional":"Subsidy% Conv",
 "indemnity_organic":"Indemnity Org ($)","indemnity_conventional":"Indemnity Conv ($)",
 "lr_diff":"LR diff (Org-Conv)",
 "cause_of_loss":"Cause of Loss","pct_of_indemnity":"% of Indemnity",
 "policies_sold":"Policies Sold","policies_earning_premium":"Policies Earning Premium",
 "policies_indemnified":"Policies Indemnified",
}
def fmt_for(colname):
    n=colname.lower()
    if "%" in colname or ("rate" in n and "loss" not in n): return PCT
    if "loss ratio" in n or "lr diff" in n: return RATIO
    if "loss cost" in n: return COST
    if "($)" in colname: return CUR
    if "records" in n or "policies" in n: return INT
    return None

def add_sheet(title, csv, sort=None, asc=False, immature=False):
    df = pd.read_csv(f"{BASE}/{csv}", dtype={"fips": str})
    if "fips" in df.columns:
        df["fips"] = df["fips"].str.zfill(5)  # keep 5-digit FIPS (leading zeros)
    if sort: df = df.sort_values(sort, ascending=asc)
    df = reorder(df)
    disp = df.rename(columns=RENAME)
    ws = wb.create_sheet(title)
    fmts = {c: fmt_for(c) for c in disp.columns}
    widths = {c: (10 if c in ("FIPS","State","Year") else (22 if "($)" in c else 15)) for c in disp.columns}
    write_df(ws, disp, fmts, widths)
    if immature and "Year" in disp.columns:
        ycol = list(disp.columns).index("Year")+1
        for ri in range(2, ws.max_row+1):
            yv = ws.cell(row=ri, column=ycol).value
            ws.cell(row=ri, column=ycol).number_format = '0'  # year no comma
            if yv in (2024,2025):
                for ci in range(1, ws.max_column+1):
                    ws.cell(row=ri, column=ci).fill = IMMATURE_FILL
    return ws

add_sheet("National", "national_summary.csv")
add_sheet("By Year", "by_year_summary.csv", sort="year", asc=True, immature=True)
add_sheet("By Insurance Plan", "by_plan_summary.csv", sort="premium_organic", asc=False)
add_sheet("By Crop", "by_crop_summary.csv", sort="premium_organic", asc=False)
add_sheet("County (all)", "county_comparison.csv", sort="premium_organic", asc=False)
add_sheet("County paired", "county_comparison_paired.csv", sort="premium_organic", asc=False)
# --- all-policies context tables (NOT organic-split; see Notes) ---
add_sheet("Cause of Loss", "cause_of_loss_summary.csv")
add_sheet("Policy Counts (Year)", "policy_counts_year.csv", immature=True)
add_sheet("Policy Counts (Crop)", "policy_counts_crop.csv")
add_sheet("Policy Counts (Plan)", "policy_counts_plan.csv")

wb.save(OUT)
print("saved", OUT)
