#!/usr/bin/env bash
# Reproduce the full organic-vs-conventional analysis from the raw RMA data.
# Prereq: run `python read_crop_loss_api.py` first to download crop_loss_data/.
# Usage:  bash analysis/run_all.sh      (run from the repo root)
set -e
cd "$(dirname "$0")/.."                       # repo root
WORK="crop_loss_data/organic_analysis/_work"
mkdir -p "$WORK"
rm -f "$WORK"/*.pkl                            # clean stale intermediates

echo "[1/6] Aggregating SOBTPU (organic vs conventional, subsidy, plan)..."
python3 analysis/agg_worker.py crop_loss_data/type_practice_usage 0 9999 "$WORK/sobtpu_part0.pkl"
echo "[2/6] Building main tables..."
python3 analysis/combine_main.py
echo "[3/6] Building figures..."
python3 analysis/make_figures.py
echo "[4/6] Aggregating cause-of-loss..."
python3 analysis/col_worker.py crop_loss_data/cost_of_loss 0 9999 "$WORK/col_part0.pkl"
echo "[5/6] Aggregating policy counts..."
python3 analysis/pol_worker.py crop_loss_data/state_county_crop 0 9999 "$WORK/pol_part0.pkl"
python3 analysis/combine_extras.py
echo "[6/6] Building Excel workbook..."
python3 analysis/build_workbook.py
echo "Done -> crop_loss_data/organic_analysis/  and  organic_vs_conventional_data.xlsx"
