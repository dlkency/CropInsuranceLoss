import sys, glob, os, pickle
import pandas as pd

DATA_DIR = sys.argv[1]; START,END=int(sys.argv[2]),int(sys.argv[3]); OUT=sys.argv[4]
files = sorted(glob.glob(os.path.join(DATA_DIR, "colsom*.txt")))[START:END]

# cost_of_loss layout (0-based): 0 year, 6 commodity, 12 cause description,
# 17 policies indemnified, 20 liability, 21 premium, 28 indemnity
cols=[0,6,12,17,20,21,28]; names=['year','crop','cause','pol_ind','liab','prem','indem']

cause={}        # cause -> [indem, pol_ind, prem, liab]
cause_year={}   # (cause,year) -> indem
for fp in files:
    print("col", os.path.basename(fp), flush=True)
    df=pd.read_csv(fp,sep='|',header=None,usecols=cols,names=names,dtype=str,encoding='latin-1',engine='c')
    for c in ['pol_ind','liab','prem','indem']:
        df[c]=pd.to_numeric(df[c],errors='coerce').fillna(0.0)
    df['year']=pd.to_numeric(df['year'],errors='coerce')
    df=df[(df.year>=2011)&(df.year<=2023)]
    df['cause']=df['cause'].str.strip()
    g=df.groupby('cause').agg(indem=('indem','sum'),pol=('pol_ind','sum'),
                              prem=('prem','sum'),liab=('liab','sum')).reset_index()
    for r in g.itertuples(index=False):
        a=cause.setdefault(r.cause,[0.,0.,0.,0.]); a[0]+=r.indem;a[1]+=r.pol;a[2]+=r.prem;a[3]+=r.liab
    gy=df.groupby(['cause','year']).agg(indem=('indem','sum')).reset_index()
    for r in gy.itertuples(index=False):
        cause_year[(r.cause,int(r.year))]=cause_year.get((r.cause,int(r.year)),0.)+r.indem
pickle.dump({'cause':cause,'cause_year':cause_year},open(OUT,'wb'))
print("done",OUT,flush=True)
