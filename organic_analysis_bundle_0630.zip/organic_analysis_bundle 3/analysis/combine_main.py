"""Build the organic-vs-conventional summary tables from the SOBTPU pickle(s)
produced by agg_worker.py. Run from the repo root.

Outputs (crop_loss_data/organic_analysis/): national_summary.csv,
by_year_summary.csv, by_plan_summary.csv, by_crop_summary.csv,
county_comparison.csv, county_comparison_paired.csv  (all include subsidy).
"""
import pickle, glob, os
import pandas as pd, numpy as np

ROOT = os.environ.get("REPO_ROOT", os.getcwd())
OUT  = os.path.join(ROOT, "crop_loss_data", "organic_analysis")
WORK = os.path.join(OUT, "_work")
os.makedirs(OUT, exist_ok=True)
MIN_ORG = 10_000

county, crop, year, plan = {}, {}, {}, {}
nat = {'organic':[0.,0.,0.,0.,0], 'conventional':[0.,0.,0.,0.,0]}
parts = sorted(glob.glob(os.path.join(WORK, "sobtpu_part*.pkl")))
if not parts:
    raise SystemExit(f"No sobtpu_part*.pkl in {WORK}. Run agg_worker.py first.")
for pf in parts:
    d = pickle.load(open(pf, 'rb'))
    for src, dst in [(d['county'],county),(d['crop'],crop),(d['year'],year),(d['plan'],plan)]:
        for k,v in src.items():
            a = dst.setdefault(k,[0.,0.,0.,0.,0])
            for i in range(5): a[i]+=v[i]
    for k,v in d['nat'].items():
        a = nat[k]
        for i in range(5): a[i]+=v[i]

def lr(i,p): return i/p if p>0 else np.nan
def lc(i,l): return i/l if l>0 else np.nan
def sr(s,p): return s/p if p>0 else np.nan
def flat(df):
    df.columns=["_".join([c for c in col if c]).strip("_") for col in df.columns.to_flat_index()]
    return df
def rowdict(keyname, key, v):   # v = [prem, indem, liab, subsidy, recs]
    return {keyname:key, "premium":v[0], "indemnity":v[1], "liability":v[2],
            "subsidy":v[3], "records":int(v[4]),
            "loss_ratio":lr(v[1],v[0]), "loss_cost":lc(v[1],v[2]), "subsidy_rate":sr(v[3],v[0])}

pd.DataFrame([rowdict("practice",k,v) for k,v in nat.items()]).to_csv(f"{OUT}/national_summary.csv", index=False)

VALS = ["loss_ratio","loss_cost","premium","subsidy","subsidy_rate"]
def pivot_summary(d, keyname, csv):
    df = pd.DataFrame([{**rowdict(keyname,k[0],v), "practice":k[1]} for k,v in d.items()])
    flat(df.pivot_table(index=keyname, columns="practice", values=VALS).reset_index()).to_csv(f"{OUT}/{csv}", index=False)

pivot_summary(year, "year", "by_year_summary.csv")
pivot_summary(plan, "plan", "by_plan_summary.csv")
pivot_summary(crop, "crop", "by_crop_summary.csv")

co = pd.DataFrame([{**rowdict("fips",k[0],v), "state":k[1], "practice":k[2]} for k,v in county.items()])
wide = flat(co.pivot_table(index=["fips","state"], columns="practice",
        values=["loss_ratio","loss_cost","premium","indemnity","subsidy"]).reset_index())
wide.to_csv(f"{OUT}/county_comparison.csv", index=False)

need=["loss_ratio_organic","loss_ratio_conventional","premium_organic","premium_conventional"]
paired = wide.dropna(subset=need).copy()
paired = paired[paired["premium_organic"]>=MIN_ORG]
paired["lr_diff"]=paired["loss_ratio_organic"]-paired["loss_ratio_conventional"]
paired.sort_values("premium_organic",ascending=False).to_csv(f"{OUT}/county_comparison_paired.csv",index=False)
print(f"main tables written to {OUT}/  ({len(paired)} paired counties)")
